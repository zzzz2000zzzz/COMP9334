% COMP9334 
% Week 4, Database server example
% After working out the balance equation, we need to solve
% the set of linear equations
% 
% I have chosen to use the first 5 equations on page 28 together
% with sum( probabilities ) = 1 
% 
% In principle, you can choose any of the 5 equations together
% with sum( probabilities ) = 1 
%
% We put the linear equations in standard form A x = b
% where x is the unknown vector  
% 
A = [ 6  -4  -2   0   0   0
     -3  10   0  -4  -2   0
     -3   0   8   0  -4  -2
      0  -3   0   4   0   0
      0  -3  -3   0   6   0
      1   1   1   1   1   1];
b = [0 0 0 0 0 1]';
x = A\b