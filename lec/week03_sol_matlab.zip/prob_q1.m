% Week 3, Revision Problem Question 1
%  
% Note: This script requires matlab function mm1 and mmm to calculate
% the response time for M/M/1 and M/M/M queues 

% Use a range of arrival rate 
lambda_v = 0.1:0.1:9.0;
Nlambda = length(lambda_v);

% The service rate 
mu = 1/0.1;

% initialiation
T_mm1 = zeros(Nlambda,1);
T_CPU2times = zeros(Nlambda,1); 
T_2queues = zeros(Nlambda,1);
T_1queue = zeros(Nlambda,1);

% For each arrival rate, calculate the response time 
for i = 1:Nlambda
    % M/M/1
    lambda = lambda_v(i);
    T_mm1(i) = mm1(lambda,mu);
    %
    % Alternative 1 - a server 2 times faster
    T_CPU2times(i) = mm1(lambda,2*mu);
    %
    % Alternative 2 - Two servers, each with a queue
    T_2queues(i) = mm1(lambda/2,mu);
    %
    % Alternative 3 - Two servers, 1 queue
    T_1queue(i) = mmm(lambda,mu,2);
end

plot(lambda_v,T_mm1,'-o',lambda_v,T_CPU2times,'-x', ...
     lambda_v,T_2queues,'-d',lambda_v,T_1queue,'-h','Linewidth',3)
legend('Original system','CPU - 2 times faster', ...
    'Two servers, 2 queues','Two servers, 1 queue', ...
    'Location','NorthWest')
xlabel('Arrival rate')
ylabel('Response time')
print -dpng prob_q1 