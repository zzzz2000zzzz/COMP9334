% Week 7, Question 2

T = [   13.64   12.78   12.21
   13.09   13.98   13.64
   13.84   13.58   13.09
   12.28   14.59   13.84
   14.55   12.72   12.28 ];

% Compute the following differenes
% System 1 - System 2
dt12 = T(:,1) - T(:,2);
% System 1 - System 3
dt13 = T(:,1) - T(:,3);
% System 2 - System 3
dt23 = T(:,2) - T(:,3);

% multiplier for confidence interval
mf = tinv(0.975,4)/sqrt(5);


% confidence interval for dt12
mean(dt12) + [-1 1]*std(dt12)*mf

% confidence interval for dt13
mean(dt13) + [-1 1]*std(dt13)*mf

% confidence interval for dt23
mean(dt23) + [-1 1]*std(dt23)*mf

